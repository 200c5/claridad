"""
Claridad — App principal
Ejecutar: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import date, timedelta
from db import (
    get_pymes, crear_pyme, get_categorias,
    registrar_gasto, registrar_ingreso,
    get_gastos, get_ingresos, eliminar_gasto, eliminar_ingreso,
    get_resumen, get_evolucion_mensual
)

# ─────────────────────────────────────
# CONFIG
# ─────────────────────────────────────
st.set_page_config(
    page_title="Claridad",
    page_icon="💚",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .metric-card {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 16px;
        border-left: 4px solid #1D9E75;
    }
    .stMetric label { font-size: 13px !important; }
    div[data-testid="metric-container"] {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 12px 16px;
    }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────
# SIDEBAR — Selección de pyme y período
# ─────────────────────────────────────
with st.sidebar:
    st.markdown("## 💚 Claridad")
    st.caption("Tu negocio, en claro")
    st.divider()

    pymes = get_pymes()

    if not pymes:
        st.warning("No hay empresas registradas.")
        with st.form("nueva_pyme"):
            nombre = st.text_input("Nombre de la empresa")
            rubro  = st.text_input("Rubro (ej: panadería, agencia)")
            if st.form_submit_button("Crear empresa"):
                crear_pyme(nombre, rubro)
                st.rerun()
        st.stop()

    nombres_pymes = [p["nombre"] for p in pymes]
    idx = st.selectbox("Empresa", range(len(pymes)), format_func=lambda i: nombres_pymes[i])
    pyme = pymes[idx]
    pyme_id = pyme["id"]

    st.divider()
    st.caption("Período de análisis")
    hoy = date.today()
    primer_dia_mes = hoy.replace(day=1)

    periodo = st.radio("Ver", ["Este mes", "Esta semana", "Últimos 30 días", "Personalizado"])

    if periodo == "Este mes":
        desde = primer_dia_mes
        hasta = hoy
    elif periodo == "Esta semana":
        desde = hoy - timedelta(days=hoy.weekday())
        hasta = hoy
    elif periodo == "Últimos 30 días":
        desde = hoy - timedelta(days=30)
        hasta = hoy
    else:
        desde = st.date_input("Desde", primer_dia_mes)
        hasta = st.date_input("Hasta", hoy)

    desde_str = desde.isoformat()
    hasta_str  = hasta.isoformat()

    st.divider()
    with st.expander("+ Nueva empresa"):
        with st.form("form_pyme"):
            n = st.text_input("Nombre")
            r = st.text_input("Rubro")
            if st.form_submit_button("Crear"):
                crear_pyme(n, r)
                st.rerun()


# ─────────────────────────────────────
# DATOS
# ─────────────────────────────────────
resumen  = get_resumen(pyme_id, desde_str, hasta_str)
gastos   = get_gastos(pyme_id, desde_str, hasta_str)
ingresos = get_ingresos(pyme_id, desde_str, hasta_str)
evolucion = get_evolucion_mensual(pyme_id, meses=6)


# ─────────────────────────────────────
# TABS PRINCIPALES
# ─────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "➕ Registrar", "📋 Historial", "📈 Evolución"])


# ══════════════════════════════════════
# TAB 1 — DASHBOARD
# ══════════════════════════════════════
with tab1:
    st.markdown(f"### {pyme['nombre']} — {periodo.lower()}")

    # KPIs grandes
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            "💰 Ingresos",
            f"USD {resumen['total_ingresos']:,.0f}",
        )
    with col2:
        st.metric(
            "💸 Gastos",
            f"USD {resumen['total_gastos']:,.0f}",
        )
    with col3:
        ganancia = resumen["ganancia"]
        delta_color = "normal" if ganancia >= 0 else "inverse"
        st.metric(
            "✅ Ganancia neta",
            f"USD {ganancia:,.0f}",
            delta=f"{resumen['margen_pct']}% de margen"
        )
    with col4:
        color_margen = "🟢" if resumen["margen_pct"] >= 30 else ("🟡" if resumen["margen_pct"] >= 10 else "🔴")
        st.metric(
            f"{color_margen} Margen",
            f"{resumen['margen_pct']}%",
            delta="Meta: 30%+"
        )

    st.divider()

    # Análisis simple en lenguaje claro
    col_msg, col_pie = st.columns([2, 1])

    with col_msg:
        st.markdown("#### 🤖 Tu resumen financiero")

        if resumen["total_ingresos"] == 0:
            st.info("Todavía no hay datos para este período. Registrá tus primeros ingresos y gastos.")
        else:
            if ganancia > 0:
                st.success(f"**Estás ganando dinero.** Por cada USD 100 que entraron, te quedaron USD {resumen['margen_pct']:.0f} limpios.")
            elif ganancia == 0:
                st.warning("**Estás en cero.** Lo que entra lo gastás entero. Revisá en qué estás gastando más.")
            else:
                st.error(f"**Estás perdiendo plata.** Gastaste USD {abs(ganancia):,.0f} más de lo que entraste.")

            # Gasto más grande
            if resumen["gastos_por_cat"]:
                top_gasto = resumen["gastos_por_cat"][0]
                pct_top = (top_gasto["total"] / resumen["total_gastos"] * 100) if resumen["total_gastos"] > 0 else 0
                st.info(f"**Tu gasto más grande:** {top_gasto['nombre']} — USD {top_gasto['total']:,.0f} ({pct_top:.0f}% del total de gastos)")

            # Gastos fijos vs variables
            if resumen["total_gastos"] > 0:
                pct_fijo = resumen["gastos_fijos"] / resumen["total_gastos"] * 100
                st.write(f"**Gastos fijos:** USD {resumen['gastos_fijos']:,.0f} ({pct_fijo:.0f}%) · **Variables:** USD {resumen['gastos_variables']:,.0f} ({100-pct_fijo:.0f}%)")

    with col_pie:
        if resumen["gastos_por_cat"]:
            df_pie = pd.DataFrame(resumen["gastos_por_cat"])
            fig = px.pie(
                df_pie, values="total", names="nombre",
                title="Gastos por categoría",
                color_discrete_sequence=px.colors.qualitative.Pastel,
                hole=0.4
            )
            fig.update_layout(showlegend=True, height=280, margin=dict(t=40,b=0,l=0,r=0))
            fig.update_traces(textposition="inside", textinfo="percent")
            st.plotly_chart(fig, use_container_width=True)

    # Tabla resumen
    if gastos or ingresos:
        st.divider()
        col_g, col_i = st.columns(2)
        with col_g:
            st.markdown("##### Últimos gastos")
            if gastos:
                df_g = pd.DataFrame(gastos)[["fecha","descripcion","categoria_nombre","monto"]]
                df_g.columns = ["Fecha","Descripción","Categoría","Monto USD"]
                df_g["Monto USD"] = df_g["Monto USD"].apply(lambda x: f"USD {x:,.0f}")
                st.dataframe(df_g.head(8), hide_index=True, use_container_width=True)
            else:
                st.caption("Sin gastos en este período.")

        with col_i:
            st.markdown("##### Últimos ingresos")
            if ingresos:
                df_i = pd.DataFrame(ingresos)[["fecha","descripcion","cliente","monto"]]
                df_i.columns = ["Fecha","Descripción","Cliente","Monto USD"]
                df_i["Monto USD"] = df_i["Monto USD"].apply(lambda x: f"USD {x:,.0f}")
                st.dataframe(df_i.head(8), hide_index=True, use_container_width=True)
            else:
                st.caption("Sin ingresos en este período.")


# ══════════════════════════════════════
# TAB 2 — REGISTRAR
# ══════════════════════════════════════
with tab2:
    col_gasto, col_ingreso = st.columns(2)

    with col_gasto:
        st.markdown("#### 💸 Registrar gasto")
        cats_gastos = get_categorias("gasto")
        cat_nombres = [c["nombre"] for c in cats_gastos]

        with st.form("form_gasto", clear_on_submit=True):
            desc    = st.text_input("Descripción *", placeholder="Ej: Compra materiales")
            monto   = st.number_input("Monto (USD) *", min_value=0.0, step=0.5)
            fecha   = st.date_input("Fecha *", value=hoy)
            cat_idx = st.selectbox("Categoría", range(len(cat_nombres)), format_func=lambda i: cat_nombres[i])
            es_fijo = st.checkbox("¿Es gasto fijo? (alquiler, sueldo, etc.)")
            notas   = st.text_area("Notas (opcional)", height=60)

            if st.form_submit_button("✅ Registrar gasto", use_container_width=True):
                if desc and monto > 0:
                    registrar_gasto(
                        pyme_id, cats_gastos[cat_idx]["id"],
                        desc, monto, fecha.isoformat(), es_fijo, notas
                    )
                    st.success(f"Gasto registrado: USD {monto:,.0f} — {desc}")
                    st.rerun()
                else:
                    st.error("Completá la descripción y el monto.")

    with col_ingreso:
        st.markdown("#### 💰 Registrar ingreso")
        cats_ingresos = get_categorias("ingreso")
        cat_ing_nombres = [c["nombre"] for c in cats_ingresos]

        with st.form("form_ingreso", clear_on_submit=True):
            desc_i  = st.text_input("Descripción *", placeholder="Ej: Venta semana 1")
            monto_i = st.number_input("Monto (USD) *", min_value=0.0, step=0.5)
            fecha_i = st.date_input("Fecha *", value=hoy)
            cliente = st.text_input("Cliente (opcional)", placeholder="Ej: Juan García")
            cat_i   = st.selectbox("Categoría", range(len(cat_ing_nombres)), format_func=lambda i: cat_ing_nombres[i])
            notas_i = st.text_area("Notas (opcional)", height=60)

            if st.form_submit_button("✅ Registrar ingreso", use_container_width=True):
                if desc_i and monto_i > 0:
                    registrar_ingreso(
                        pyme_id, cats_ingresos[cat_i]["id"],
                        desc_i, monto_i, fecha_i.isoformat(), cliente, notas_i
                    )
                    st.success(f"Ingreso registrado: USD {monto_i:,.0f} — {desc_i}")
                    st.rerun()
                else:
                    st.error("Completá la descripción y el monto.")


# ══════════════════════════════════════
# TAB 3 — HISTORIAL
# ══════════════════════════════════════
with tab3:
    st.markdown("#### 📋 Historial de movimientos")

    subtab_g, subtab_i = st.tabs(["Gastos", "Ingresos"])

    with subtab_g:
        if gastos:
            df_gh = pd.DataFrame(gastos)
            df_gh["fijo"] = df_gh["es_fijo"].apply(lambda x: "Fijo" if x else "Variable")
            df_show = df_gh[["fecha","descripcion","categoria_nombre","monto","fijo","notas","id"]]
            df_show.columns = ["Fecha","Descripción","Categoría","Monto USD","Tipo","Notas","id"]

            st.dataframe(
                df_show.drop(columns=["id"]),
                hide_index=True, use_container_width=True
            )

            id_eliminar = st.number_input("ID de gasto a eliminar (opcional)", min_value=0, step=1, value=0)
            if st.button("🗑 Eliminar gasto") and id_eliminar > 0:
                eliminar_gasto(id_eliminar)
                st.success("Eliminado.")
                st.rerun()
        else:
            st.info("No hay gastos en este período.")

    with subtab_i:
        if ingresos:
            df_ih = pd.DataFrame(ingresos)
            df_show_i = df_ih[["fecha","descripcion","cliente","categoria_nombre","monto","notas","id"]]
            df_show_i.columns = ["Fecha","Descripción","Cliente","Categoría","Monto USD","Notas","id"]

            st.dataframe(
                df_show_i.drop(columns=["id"]),
                hide_index=True, use_container_width=True
            )

            id_elim_i = st.number_input("ID de ingreso a eliminar (opcional)", min_value=0, step=1, value=0)
            if st.button("🗑 Eliminar ingreso") and id_elim_i > 0:
                eliminar_ingreso(id_elim_i)
                st.success("Eliminado.")
                st.rerun()
        else:
            st.info("No hay ingresos en este período.")


# ══════════════════════════════════════
# TAB 4 — EVOLUCIÓN
# ══════════════════════════════════════
with tab4:
    st.markdown("#### 📈 Evolución de los últimos 6 meses")

    if evolucion:
        df_ev = pd.DataFrame(evolucion)

        fig = go.Figure()
        fig.add_bar(name="Ingresos", x=df_ev["mes"], y=df_ev["ingresos"],
                    marker_color="#1D9E75", opacity=0.85)
        fig.add_bar(name="Gastos",   x=df_ev["mes"], y=df_ev["gastos"],
                    marker_color="#E24B4A", opacity=0.85)
        fig.add_scatter(name="Ganancia", x=df_ev["mes"], y=df_ev["ganancia"],
                        mode="lines+markers", line=dict(color="#7F77DD", width=2),
                        marker=dict(size=7))
        fig.update_layout(
            barmode="group",
            height=380,
            legend=dict(orientation="h", yanchor="bottom", y=1.02),
            margin=dict(t=20, b=20),
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            yaxis=dict(title="USD"),
        )
        st.plotly_chart(fig, use_container_width=True)

        # Tabla resumen
        df_ev["margen"] = df_ev.apply(
            lambda r: f"{r['ganancia']/r['ingresos']*100:.1f}%" if r["ingresos"] > 0 else "—", axis=1
        )
        df_ev.columns = ["Mes","Ingresos USD","Gastos USD","Ganancia USD","Margen"]
        df_ev["Ingresos USD"] = df_ev["Ingresos USD"].apply(lambda x: f"USD {x:,.0f}")
        df_ev["Gastos USD"]   = df_ev["Gastos USD"].apply(lambda x: f"USD {x:,.0f}")
        df_ev["Ganancia USD"] = df_ev["Ganancia USD"].apply(lambda x: f"USD {x:,.0f}")
        st.dataframe(df_ev, hide_index=True, use_container_width=True)
    else:
        st.info("Cargá datos para ver la evolución histórica.")
